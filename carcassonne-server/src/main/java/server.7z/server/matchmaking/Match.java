package server.matchmaking;

import logic.Game;
import logic.GameTurn;
import logic.IGameListener;
import logic.command.EndTurnCommand;
import logic.command.ICommand;
import logic.command.PlaceTileDrawnCommand;
import logic.config.GameConfig;
import logic.player.Player;
import logic.tile.ChunkId;
import logic.tile.Tile;
import network.message.Message;
import network.message.game.GameCommandMessage;
import network.message.game.GameDataMessage;
import network.message.game.GameResultMessage;
import server.logger.Logger;
import server.session.ClientSession;
import stream.ByteOutputStream;

public class Match implements IGameListener {
    private final int id;
    private final ClientSession[] sessions;
    private final Game game;

    public Match(int id, ClientSession[] sessions) {
        this.id = id;
        this.sessions = sessions;
        this.game = new Game(GameConfig.loadFromResources());
        game.setListener(this);
    }

    public void removePlayer(ClientSession session) {
        for (int i = 0; i < sessions.length; i++) {
            if (sessions[i] == session) {
                sessions[i] = null;
            }
        }
    }

    private void startGame() {
        game.start();
    }

    private void updateGame() {
        game.update();
    }

    private ClientSession getSessionByUserId(int userId) {
        for (ClientSession session : sessions) {
            if (session != null && session.getUserId() == userId) {
                return session;
            }
        }
        return null;
    }

    private void sendMessageToConnectedClients(Message message) {
        for (ClientSession session : sessions) {
            if (session != null) {
                session.getConnection().send(message);
            }
        }
    }

    public void executeCommand(int userId, ICommand command) {
        GameTurn turn = game.getTurn();

        if (turn.isOver()) {
            Logger.warn("Player %d tried to execute command %s but the current turn is over.", userId, command);
            return;
        }

        if (turn.getPlayer().getId() != userId) {
            Logger.warn("Player %d tried to execute command %s but it is not his turn", userId, command.getType());
            return;
        }

        if (!command.execute(game)) {
            Logger.warn("Player %d tried to execute command %s but it failed", userId, command.getType());
            return;
        }

        Logger.info("Player %d executed command %s", userId, command.getType());

        sendMessageToConnectedClients(new GameCommandMessage(command));
        updateGame();
    }

    @Override
    public void onTurnStarted(int id) {
        GameTurn turn = game.getTurn();
        int userId = turn.getPlayer().getId();

        if (getSessionByUserId(userId) == null) {
            Logger.info("Player %d left the game. Tile to draw will be placed randomly to continue the game.",userId);
            executeCommand(userId, new PlaceTileDrawnCommand(game.getBoard().findFreePlaceForTile(turn.getTileToDraw()).get(0)));
            executeCommand(userId, new EndTurnCommand());
        }
    }

    @Override
    public void onTurnEnded(int id) {
        updateGame();
    }

    @Override
    public void onTilePlaced(Tile tile) {
        Logger.debug("Match %d: Tile model %s placed at (%d,%d)", tile.getConfig().model, tile.getPosition().getX(), tile.getPosition().getY());
    }

    @Override
    public void onMeeplePlaced(Player player, Tile tile, ChunkId chunkId) {
        Logger.debug("Match %d: Meeple placed at tile (%d,%d), chunk %s", tile.getPosition().getX(), tile.getPosition().getY(), chunkId);
    }

    @Override
    public void onMeepleRemoved(Player player, Tile tile, ChunkId chunkId) {
        Logger.debug("Match %d: Meeple removed from tile (%d,%d), chunk %s", tile.getPosition().getX(), tile.getPosition().getY(), chunkId);
    }

    @Override
    public void onStart() {
        Logger.info("Match %d: Game started", id);

        ByteOutputStream stream = new ByteOutputStream(1000);
        game.encode(stream);
        sendMessageToConnectedClients(new GameDataMessage(stream.toByteArray()));
    }

    @Override
    public void onEnd() {
        Logger.info("Match %d: Game ended", id);
        sendMessageToConnectedClients(new GameResultMessage());
    }

    @Override
    public void onCommandFailed(String reason) {
        Logger.warn("Match %d: Command failed: %s", id, reason);
    }

    @Override
    public void onCommandFailed(String reason, Object... args) {
        Logger.warn("Match %d: Command failed: %s", id, String.format(reason, args));
    }
}
